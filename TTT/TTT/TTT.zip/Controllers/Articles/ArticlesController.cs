﻿using HPYL.Common;
using HPYL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using XL.Model.Message;
using C = HPYL.Common;
using B = HPYL.BLL;
namespace HPYL_API.Controllers
{
    /// <summary>
    /// 新闻控制器
    /// </summary>
    public class ArticlesController : ApiController
    {
        /// <summary>
        /// 资讯列表
        /// </summary>
        /// <param name="NewsClass"></param>
        /// <param name="Sign"></param>
        /// <param name="Ts"></param>
        /// <returns></returns>
        [HttpGet]
        public CallBackResult List(string NewsClass, string Sign, string Ts)
        {
            CallBackResult apiResult = new CallBackResult();
            if (!C.ComHelper.CheckRequest(Sign, Ts, out apiResult.Result, out apiResult.Message))
            {
                return apiResult;
            }
            B.ArticlesBLL bll = new B.ArticlesBLL();
            List<HPYL.Model.Articles> mlist = bll.GetModelList(NewsClass);
            apiResult.Data = mlist;
            if (apiResult.Data != null && mlist.Count > 0)
            {
                apiResult.Result = 1;
                apiResult.Message = "加载成功!";

            }
            else
            {
                apiResult.Result = 2;
                apiResult.Message = "无数据!";
            }

            return apiResult;
        }
        /// <summary>
        /// 新闻详情
        /// </summary>
        /// <param name="NewsId"></param>
        /// <param name="Sign"></param>
        /// <param name="Ts"></param>
        /// <returns></returns>
        [HttpGet]
        public CallBackResult Detail(string NewsId, string Sign, string Ts)
        {
            CallBackResult apiResult = new CallBackResult();
            if (!C.ComHelper.CheckRequest(Sign, Ts, out apiResult.Result, out apiResult.Message))
            {
                return apiResult;
            }
            B.ArticlesBLL bll = new B.ArticlesBLL();
            HPYL.Model.Articles model = bll.GetModel(NewsId);
            apiResult.Data = model;
            if (apiResult.Data != null)
            {
                apiResult.Result = 1;
                apiResult.Message = "加载成功!";

            }
            else
            {
                apiResult.Result = 2;
                apiResult.Message = "加载失败!";
            }

            return apiResult;
        }
    }
}
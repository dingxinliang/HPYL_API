﻿using HPYL.Common;
using HPYL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using XL.Model.Message;
using C = HPYL.Common;
using B = HPYL.BLL;
namespace HPYL_API.Controllers
{
    /// <summary>
    /// 用户控制器
    /// </summary>
    public class MembersController : ApiController
    {
        /// <summary>
        /// 用户登陆
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        [HttpPost]
        public CallBackResult MembersLogin([FromBody]LoginMembers obj)
        {
            CallBackResult apiResult = new CallBackResult();
            try
            {
                //检查请求 签名和时间戳不符合即返回
                if (!C.ComHelper.CheckRequest(obj, out apiResult.Result, out apiResult.Message))
                {
                    return apiResult;
                }
                B.Members bll = new B.Members();
                //验证验证码
                if (bll.Checkcode(obj.LoginPhone, obj.PhoneCode, "login"))
                {
                    Members loginM = bll.GetLoginPhoneCode(obj.LoginPhone, obj.PhoneCode);
                    if (loginM != null)
                    {
                        if (loginM.Disabled == 0)
                        {
                            apiResult.Data = loginM;
                            apiResult.Result = 1;
                            apiResult.Message = "登录成功!";
                        }
                        else
                        {
                            apiResult.Result = 2;
                            apiResult.Message = "账户已停用!";
                        }
                    }
                    else
                    {
                        apiResult.Result = 0;
                        apiResult.Message = "用户不存在!";
                    }
                }
                else
                {
                    apiResult.Result = 4;
                    apiResult.Message = "验证码不存在或已失效!";

                }
            }
            catch (Exception ex)
            {
                apiResult.Result = 0;
                apiResult.Message = "服务器通信失败";
                Log.Debug("登录", ex.Message);

            }
            return apiResult;
        }
        /// <summary>
        /// 用户注册
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        [HttpPost]
        public CallBackResult Register([FromBody]MRegister obj)
        {
            CallBackResult apiResult = new CallBackResult();
            //检查请求 签名和时间戳不符合即返回
            if (!C.ComHelper.CheckRequest(obj, out apiResult.Result, out apiResult.Message))
            {
                return apiResult;
            }
            //Register
            B.Members bll = new B.Members();
            bool isTrue = bll.Register(obj);
            if (isTrue)
            {
                apiResult.Result = 1;
                apiResult.Message = "注册成功!";
            }
            else
            {
                apiResult.Result = 2;
                apiResult.Message = "注册失败\n已注册过!";
            }
            return apiResult;
        }

    }
}
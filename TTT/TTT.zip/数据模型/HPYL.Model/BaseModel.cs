﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HPYL.Model
{
    public class BaseModel
    {
        //签名
        public string Sign { get; set; }
        //Token
        //public string Token { get; set; }
        //时间戳
        public string Ts { get; set; }
    }
}
